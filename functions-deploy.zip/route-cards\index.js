"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routeCards = routeCards;
const functions_1 = require("@azure/functions");
const cors_1 = require("../shared/cors");
const cosmos_1 = require("../shared/cosmos");
function isCosmosDBConfigured() {
    return !!(process.env.COSMOSDB_ENDPOINT &&
        process.env.COSMOSDB_KEY &&
        process.env.COSMOSDB_ENDPOINT.trim() !== '' &&
        process.env.COSMOSDB_KEY.trim() !== '');
}
async function routeCards(request, context) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
        return {
            status: 204,
            headers: cors_1.corsHeaders,
        };
    }
    try {
        if (request.method === 'GET') {
            const regionParam = request.query.get('region');
            const enabledParam = request.query.get('enabled');
            const validRegions = ['europe', 'latin-america', 'southeast-asia'];
            const region = regionParam && validRegions.includes(regionParam)
                ? regionParam
                : undefined;
            const enabled = enabledParam === null || enabledParam === undefined
                ? undefined
                : enabledParam === 'true'
                    ? true
                    : false;
            if (!isCosmosDBConfigured()) {
                return (0, cors_1.createCorsResponse)({ routeCards: [] });
            }
            const routeCards = await (0, cosmos_1.getRouteCards)({
                ...(region ? { region } : {}),
                ...(typeof enabled === 'boolean' ? { enabled } : {}),
            });
            return (0, cors_1.createCorsResponse)({ routeCards });
        }
        if (request.method === 'POST') {
            const body = (await request.json());
            if (!body?.name || !body?.region) {
                return (0, cors_1.createCorsResponse)({ error: 'Missing required fields: name, region' }, 400);
            }
            const validRegions = ['europe', 'latin-america', 'southeast-asia'];
            if (!validRegions.includes(body.region)) {
                return (0, cors_1.createCorsResponse)({ error: `Invalid region. Must be one of: ${validRegions.join(', ')}` }, 400);
            }
            if (!isCosmosDBConfigured()) {
                return (0, cors_1.createCorsResponse)({ error: 'CosmosDB is not configured' }, 500);
            }
            const routeCard = await (0, cosmos_1.createRouteCard)({
                name: String(body.name).trim(),
                region: body.region,
                tagline: String(body.tagline || '').trim(),
                icon: String(body.icon || '').trim(),
                imageUrl: String(body.imageUrl || '').trim(),
                budget: String(body.budget || '').trim(),
                budgetLabel: String(body.budgetLabel || '').trim(),
                timezone: String(body.timezone || '').trim(),
                vibe: String(body.vibe || '').trim(),
                overview: String(body.overview || '').trim(),
                featuredCities: Array.isArray(body.featuredCities) ? body.featuredCities.map(c => String(c).trim()) : [],
                enabled: body.enabled ?? true,
                order: typeof body.order === 'number' && Number.isFinite(body.order) ? body.order : 0,
            });
            return (0, cors_1.createCorsResponse)({ routeCard }, 201);
        }
        return (0, cors_1.createCorsResponse)({ error: 'Method not allowed' }, 405);
    }
    catch (error) {
        context.log(`Error processing route cards request: ${error instanceof Error ? error.message : String(error)}`);
        return (0, cors_1.createCorsResponse)({
            error: error.message || 'Failed to process request',
            details: process.env.NODE_ENV === 'development' ? error.stack : undefined,
        }, 500);
    }
}
functions_1.app.http('route-cards', {
    methods: ['GET', 'POST', 'OPTIONS'],
    authLevel: 'anonymous',
    handler: routeCards,
});
//# sourceMappingURL=index.js.map